GALIFONT
A Chicken-Inspired Display Font

---

DESCRIPTION
Galifont is a fun, rounded and playful display font inspired by the shapes and personality of chickens.

This font was specially created for the brand "M Chickens", a school project developed as part of a creative and educational initiative.

It was designed to bring a light, creative and humorous touch to visual projects, making it perfect for titles, logos, posters and cartoon-style designs.

Its soft curves and unique style give it a friendly and distinctive appearance, ideal for standing out in creative compositions.

---

FONT DETAILS
Font Name: Galifont
Version: 3.200
Release Year: 2025
Author: João Pedro

---

CHARACTER SET
This font includes:

* Uppercase letters (A–Z)
* Lowercase letters (a–z)
* Numbers (0–9)
* Basic punctuation

---

USAGE
Galifont is free for personal use only.

You are allowed to use this font in personal projects such as school work, social media posts, and non-commercial designs.

For commercial use (including branding, logos, products for sale, or business use), please contact the author.

---

INSTALLATION
To install the font:

Windows:

* Right-click the .TTF or .OTF file and click "Install"

Mac:

* Double-click the font file and click "Install Font"

---

CONTACT
For commercial licenses, questions or feedback:

Author: João Pedro
mchickensetec@gmail.com

---

NOTE
This font was originally created for the "M Chickens" school project.

Please do not redistribute this font without permission.
If you share it, always link back to the original source.

---

Thank you for downloading Galifont!
Your support means a lot. 🐔
